alert("le fichier javascript a été chargé");

//charger le document xml ici
